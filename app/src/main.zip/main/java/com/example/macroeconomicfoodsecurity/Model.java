package com.example.macroeconomicfoodsecurity;

public class Model {

    public String year;
    public String china;
    public String india;
    public String usa;

    public Model(String year, String india, String china, String usa) {
        this.year = year;
        this.china = china;
        this.india = india;
        this.usa = usa;
    }

}
